// Hero orbit: the anchor, its rings, the pulses and the light points drawn as ONE scene in a
// single fragment shader, so they share the same light, depth and glow. Rings pass in front of
// and behind the anchor, the chrome reflects the rings, and the glow belongs to both.
// The text chips stay as HTML (crisp, accessible) and are placed by v3.js on the same ellipses;
// chips behind the anchor sit under this canvas, so the anchor hides them as it should.
// No WebGL, or Save-Data on: the SVG version underneath stays as it is.
const canvas = document.querySelector('[data-orbgl]');
const orb = document.querySelector('[data-orb]');
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const saveData = navigator.connection?.saveData;

const VERT = `attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}`;
const FRAG = `
precision highp float;
uniform vec2 uRes, uMouse;
uniform float uTime;
uniform vec4 uChip[5];

#define SPAN 336.
#define S .78
#define CY -.055
#define WK 2.1667
const vec3 BLUE=vec3(.494,.635,1.);
const vec3 TEAL=vec3(.247,.847,.776);

mat2 rot(float a){ float c=cos(a), s=sin(a); return mat2(c,-s,s,c); }
float torus(vec3 p, float R, float r){ return length(vec2(length(p.xy)-R,p.z))-r; }
float arc(vec3 p, vec2 sc, float ra, float rb){ p.x=abs(p.x); float k=(sc.y*p.x>sc.x*p.y)?dot(p.xy,sc):length(p.xy); return sqrt(dot(p,p)+ra*ra-2.*ra*k)-rb; }
float box(vec3 p, vec3 b, float r){ vec3 q=abs(p)-b; return length(max(q,0.))+min(max(q.x,max(q.y,q.z)),0.)-r; }

// The anchor: one rigid piece that sways gently and leans with the pointer.
vec2 map(vec3 p){
  p.y -= sin(uTime*.7)*.035;
  vec3 q=p; q.yz*=rot(-.12+uMouse.y*.16);
  q.xz*=rot(sin(uTime*.23)*.5+uMouse.x*.45);
  float d=torus(q-vec3(0.,1.02,0.),.3,.066);
  d=min(d,box(q-vec3(0.,-.02,0.),vec3(.034,.56,.17),.03));
  vec3 a=q-vec3(0.,-.06,0.); a.y=-a.y;
  d=min(d,arc(a,vec2(.932,.362),.96,.07));
  float b=length(q-vec3(0.,-.8,0.))-.085;
  return b<d ? vec2(b,2.) : vec2(d,0.);
}
vec3 normal(vec3 p){ vec2 e=vec2(.0015,-.0015); return normalize(e.xyy*map(p+e.xyy).x+e.yyx*map(p+e.yyx).x+e.yxy*map(p+e.yxy).x+e.xxx*map(p+e.xxx).x); }

// A ring's plane in world space (rx, ry, rotation in degrees, exactly as the SVG/HTML use them).
vec3 ringN(float rx, float ry, float rd){
  float r=radians(rd), c=ry/rx, s=sqrt(1.-c*c);
  vec3 u=vec3(cos(r),-sin(r),0.), v=vec3(-sin(r)*c,-cos(r)*c,s);
  return normalize(cross(u,v));
}
vec3 ringU(float rd){ float r=radians(rd); return vec3(cos(r),-sin(r),0.); }

// Studio light plus the rings themselves: seen from the anchor, each ring is a band of light
// along its own plane, so the chrome reflects the orbit around it.
vec3 env(vec3 d){
  vec3 c=mix(vec3(.008,.01,.02),vec3(.04,.06,.14),d.y*.5+.5);
  c+=vec3(1.6)*smoothstep(.72,.96,dot(d,normalize(vec3(.5,.75,.45))));
  c+=vec3(.6,.92,1.)*1.1*smoothstep(.62,.98,dot(d,normalize(vec3(-.3,-.62,-.72))));
  vec3 n0=ringN(250.,70.,-16.), n1=ringN(190.,118.,24.), n2=ringN(282.,44.,6.);
  float t0=dot(d,ringU(-16.))*.5+.5, t1=dot(d,ringU(24.))*.5+.5, t2=dot(d,ringU(6.))*.5+.5;
  c+=mix(BLUE,TEAL,t0)*2.2*smoothstep(.09,0.,abs(dot(d,n0)))*(.25+t0);
  c+=mix(BLUE,TEAL,t1)*1.4*smoothstep(.07,0.,abs(dot(d,n1)))*(.25+t1);
  c+=mix(BLUE,TEAL,t2)*1.2*smoothstep(.05,0.,abs(dot(d,n2)))*(.25+t2);
  return c;
}

// One orbit line: anti-aliased core and soft glow, the same gradient as the SVG, brighter near
// the anchor and on the near side, hidden where it passes behind the anchor.
vec4 ring(vec2 s, float rx, float ry, float rd, float w, float op, float dash, float hitZ, float px){
  float r=radians(rd), c=cos(r), sn=sin(r);
  vec2 l=vec2(s.x*c+s.y*sn, -s.x*sn+s.y*c);
  vec2 ab=vec2(rx,ry);
  float k0=length(l/ab), k1=length(l/(ab*ab));
  float d=abs((k0-1.)*k0/max(k1,1e-5));
  float ph=atan(l.y/ry,l.x/rx), fr=sin(ph);
  float z=fr*(rx/300./S*WK)*sqrt(1.-ry*ry/(rx*rx));
  float vis=z<hitZ ? 0. : 1.;
  float t=clamp(l.x/rx*.5+.5,0.,1.);
  float g=t<.5 ? mix(.12,1.,t*2.) : mix(1.,.22,(t-.5)*2.);
  vec3 cc=mix(BLUE,TEAL,smoothstep(.45,1.,t));
  float depth=.5+.5*(fr*.5+.5);
  float core=1.-smoothstep(w*.5, w*.5+px*1.1, d);
  float glow=exp(-d/7.)*.2;
  if(dash>0.){ float m=fract((ph*(rx+ry)*.5+uTime*dash)/11.); core*=smoothstep(0.,.05,m)*(1.-smoothstep(.15,.22,m)); glow*=.55; }
  float near=1.+1.3*exp(-length(s)/120.);
  float I=(core*1.25+glow)*g*depth*op*near*vis;
  return vec4(cc*I, core*g*op*vis*.85);
}

float sdRBox(vec2 p, vec2 b, float r){ vec2 q=abs(p)-b+r; return length(max(q,0.))+min(max(q.x,q.y),0.)-r; }

void main(){
  vec2 uv=(gl_FragCoord.xy*2.-uRes)/uRes.y;
  vec2 s=vec2(uv.x,-uv.y)*SPAN;          // SVG units: centre 0, y down
  float px=2.*SPAN/uRes.y;
  float rr=length(s);

  // Shared bloom: the light the whole orbit sits in
  vec3 col=vec3(.2,.38,1.)*(.26*exp(-rr/90.)+.09*exp(-rr/200.));

  // The anchor
  vec2 a=(vec2(s.x,-s.y)/300.-vec2(0.,CY))/S;
  float hitZ=-1e3, aal=0.; vec3 acol=vec3(0.);
  float edge=min(.86-abs(a.x),min(a.y+.86,1.02-a.y));
  if(edge>0.){
    vec3 ro=vec3(0.,0.,5.2), rd=normalize(vec3(a,-2.4));
    float t=3.4, md=1e3, id=0.; bool hit=false;
    for(int i=0;i<72;i++){
      vec2 m=map(ro+rd*t); md=min(md,m.x);
      if(m.x<.0015*t){ hit=true; id=m.y; break; }
      t+=m.x*.92; if(t>7.2) break;
    }
    if(hit){
      vec3 p=ro+rd*t, n=normal(p);
      float f=pow(1.-max(dot(n,-rd),0.),5.);
      vec3 e=env(reflect(rd,n));
      vec3 c=e*mix(vec3(.62,.7,.88),vec3(1.),f)+f*vec3(.15,.32,1.)*.9+vec3(.012,.018,.04);
      c+=vec3(.2,.4,1.)*.12*(1.-abs(n.z));
      if(id>1.5) c=vec3(.16,.34,1.)*(1.6+2.*f)+e*.5;
      c=c/(1.+c); c=pow(c,vec3(.4545));
      acol=c; aal=1.; hitZ=p.z;
    } else {
      col+=vec3(.25,.45,1.)*exp(-md*6.)*.42*smoothstep(0.,.18,edge);
    }
  }

  // Back-chip cut-outs so a ring never draws through a chip that sits behind it
  float mask=1.;
  for(int j=0;j<5;j++){ vec4 cp=uChip[j]; if(cp.z>0.) mask*=smoothstep(-1.,3.,sdRBox(s-cp.xy,cp.zw,cp.w)); }

  // Orbits, pulses and light points
  vec4 L=ring(s,250.,70.,-16.,1.5,1.,0.,hitZ,px)
        +ring(s,190.,118.,24.,1.9,1.,11.,hitZ,px)
        +ring(s,282.,44.,6.,1.1,.75,0.,hitZ,px);
  for(int k=0;k<2;k++){
    float f=fract(uTime/6.+float(k)*.5), sc=mix(.32,1.08,f);
    L+=ring(s,250.*sc,70.*sc,-16.,1.2,(1.-f)*(1.-f)*.55,0.,hitZ,px);
  }
  for(int i=0;i<10;i++){
    float fi=float(i); int ri=i-3*(i/3);
    float rx=250., ry=70., rd=-16.;
    if(ri==1){ rx=190.; ry=118.; rd=24.; } else if(ri==2){ rx=282.; ry=44.; rd=6.; }
    float sp=(mod(fi,2.)>.5 ? -1. : 1.)*(.03+mod(fi,4.)*.012);
    float an=fi*.73+sp*6.*uTime;
    float r=radians(rd), x=cos(an)*rx, y=sin(an)*ry;
    vec2 P=vec2(x*cos(r)-y*sin(r), x*sin(r)+y*cos(r));
    float fr=sin(an), z=fr*(rx/300./S*WK)*sqrt(1.-ry*ry/(rx*rx));
    if(z<hitZ) continue;
    float dd=length(s-P), sz=2.2+1.4*(fr*.5+.5);
    float c=1.-smoothstep(sz-px*.8,sz+px*.8,dd), h=exp(-dd/6.)*.7;
    L+=vec4(vec3(.81,.88,1.)*c*1.3+vec3(.35,.55,1.)*h, c);
  }
  L*=mask;

  col=col*(1.-aal)+acol*aal+L.rgb;
  float al=max(aal,max(L.a,max(col.r,max(col.g,col.b))));
  gl_FragColor=vec4(min(col,vec3(al)),clamp(al,0.,1.));
}`;

function start() {
  const gl = canvas.getContext('webgl', { alpha: true, antialias: false, premultipliedAlpha: true, powerPreference: 'high-performance' });
  if (!gl) return;
  const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
  const prog = gl.createProgram();
  try { gl.attachShader(prog, sh(gl.VERTEX_SHADER, VERT)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FRAG)); } catch (e) { console.warn('Orbit shader unavailable:', e.message); return; }
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return;
  gl.useProgram(prog);
  gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(prog, 'a');
  gl.enableVertexAttribArray(loc);
  gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const U = Object.fromEntries(['uRes', 'uMouse', 'uTime', 'uChip'].map((n) => [n, gl.getUniformLocation(prog, n)]));

  function resize() {
    // Supersampled so the anchor and the thin orbit lines stay crisp.
    const dpr = Math.min(2, Math.max(1.5, devicePixelRatio || 1));
    const w = Math.max(2, Math.round(canvas.clientWidth * dpr)), h = Math.max(2, Math.round(canvas.clientHeight * dpr));
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; gl.viewport(0, 0, w, h); }
    gl.uniform2f(U.uRes, w, h);
  }
  new ResizeObserver(resize).observe(canvas);
  resize();

  const mouse = { x: 0, y: 0, tx: 0, ty: 0 };
  addEventListener('pointermove', (e) => { mouse.tx = (e.clientX / innerWidth) * 2 - 1; mouse.ty = -((e.clientY / innerHeight) * 2 - 1); }, { passive: true });

  const empty = new Float32Array(20);
  let visible = true, raf = 0, frames = 0;
  const t0 = performance.now();
  function frame(now) {
    raf = 0;
    if (!visible || document.hidden) return;
    mouse.x += (mouse.tx - mouse.x) * 0.05; mouse.y += (mouse.ty - mouse.y) * 0.05;
    gl.uniform1f(U.uTime, reduce ? 3.1 : (now - t0) / 1000);
    gl.uniform2f(U.uMouse, mouse.x, mouse.y);
    gl.uniform4fv(U.uChip, orb.__chips || empty);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    if (frames++ === 1) { canvas.classList.add('is-on'); orb.classList.add('is-gl'); }
    if (!reduce) raf = requestAnimationFrame(frame);
  }
  const kick = () => { if (!raf) raf = requestAnimationFrame(frame); };
  new IntersectionObserver(([e]) => { visible = e.isIntersecting; if (visible) kick(); }).observe(canvas);
  document.addEventListener('visibilitychange', kick);
  if (reduce) { addEventListener('resize', kick); requestAnimationFrame(() => requestAnimationFrame(frame)); }
  canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); canvas.classList.remove('is-on'); orb.classList.remove('is-gl'); });
  kick();
}

if (canvas && orb && !saveData) {
  (window.requestIdleCallback ? (f) => requestIdleCallback(f, { timeout: 700 }) : (f) => setTimeout(f, 200))(start);
}
