// Contact form: validates in the browser, posts to the handler set in site.config.mjs
// (default /api/contact.php), then shows the confirmation screen or a clear error.
const form = document.querySelector('[data-form]');
if (form) {
  const $ = (s) => form.querySelector(s);
  const card = document.querySelector('[data-formcard]');
  const done = document.querySelector('[data-done]');
  const errBox = $('[data-form-error]');
  const submit = $('[data-submit]');
  $('[data-ts]').value = Date.now(); // the handler rejects forms sent implausibly fast

  // Pre-fill from links such as /contact/?service=seo or ?call=1
  const q = new URLSearchParams(location.search);
  const svc = q.get('service');
  if (svc) { const o = form.querySelector(`option[data-slug="${CSS.escape(svc)}"]`); if (o) o.selected = true; }
  if (q.has('call')) $('#f-call').checked = true;
  if (q.has('estimate')) $('#f-message').placeholder = 'Tell us about the project you’d like an estimate for.';
  document.querySelector('[data-call-link]')?.addEventListener('click', (e) => { e.preventDefault(); $('#f-call').checked = true; $('#f-first_name').focus(); });

  const rules = {
    first_name: (v) => (v ? '' : 'Enter your first name.'),
    last_name: (v) => (v ? '' : 'Enter your last name.'),
    email: (v) => (!v ? 'Enter your email address.' : /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? '' : 'Enter an email address like name@company.co.uk.'),
    service: (v) => (v ? '' : 'Choose what you need help with.'),
    message: (v) => (v.length >= 10 ? '' : 'Tell us a little about what you need (at least 10 characters).'),
  };
  const check = (name) => {
    const el = form.elements[name], msg = rules[name](el.value.trim()), err = document.getElementById('e-' + name);
    el.setAttribute('aria-invalid', String(!!msg));
    err.textContent = msg; err.hidden = !msg;
    return !msg;
  };
  Object.keys(rules).forEach((n) => {
    form.elements[n].addEventListener('blur', () => check(n));
    form.elements[n].addEventListener('input', () => form.elements[n].getAttribute('aria-invalid') === 'true' && check(n));
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errBox.hidden = true;
    const bad = Object.keys(rules).filter((n) => !check(n));
    if (bad.length) { form.elements[bad[0]].focus(); return; }
    form.classList.add('is-sending'); submit.disabled = true; submit.querySelector('span').textContent = 'Sending…';
    try {
      // Preview builds have no server: show the confirmation without sending anything.
      if (window.ADS?.preview) { await new Promise((r) => setTimeout(r, 700)); form.hidden = true; done.hidden = false; done.focus(); return; }
      const res = await fetch(form.action, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) throw new Error(data.error || 'send-failed');
      form.hidden = true; done.hidden = false; done.focus();
      card.scrollIntoView({ block: 'center', behavior: 'smooth' });
      window.adsTrack?.('generate_lead', { service: form.elements.service.value });
    } catch (err) {
      const email = document.querySelector('.contact__d a[href^="mailto:"]');
      const known = { validation: 'Some details look incomplete. Check the form and send it again.', rate: 'You’ve sent several enquiries in a short time. Wait a few minutes and send it again.' };
      errBox.innerHTML = (known[err.message] || 'Your enquiry wasn’t sent because the server didn’t respond. Nothing you typed has been lost, so send it again') + (email && !known[err.message] ? `, or email us at <a href="${email.href}">${email.textContent}</a>.` : '');
      errBox.hidden = false;
    } finally {
      form.classList.remove('is-sending'); submit.disabled = false; submit.querySelector('span').textContent = 'Send Enquiry';
    }
  });
}
