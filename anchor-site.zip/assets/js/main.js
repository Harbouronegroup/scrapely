// Site-wide behaviour: navigation, scroll-linked motion, pointer micro-interactions, consent.
// No libraries. Everything degrades to a static page with JavaScript off or reduced motion on.
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const root = document.documentElement;

/* ── Navigation ───────────────────────────────────────────── */
const nav = $('[data-nav]');
const menu = $('[data-menu]');
const toggle = $('[data-menu-toggle]');
function setMenu(open) {
  menu.hidden = !open;
  toggle.setAttribute('aria-expanded', String(open));
  $('.nav__toggle-l', toggle).textContent = open ? 'Close' : 'Menu';
  root.classList.toggle('menu-open', open);
  document.body.style.overflow = open ? 'hidden' : '';
  if (open) $('a', menu)?.focus({ preventScroll: true });
}
toggle?.addEventListener('click', () => setMenu(menu.hidden));
addEventListener('keydown', (e) => {
  if (menu.hidden) return;
  if (e.key === 'Escape') { setMenu(false); toggle.focus(); }
  if (e.key === 'Tab') {
    // Keep keyboard focus inside the open menu (plus the toggle button).
    const f = [toggle, ...$$('a, button', menu)];
    const i = f.indexOf(document.activeElement);
    if (e.shiftKey && i <= 0) { e.preventDefault(); f.at(-1).focus(); }
    else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); }
  }
});
matchMedia('(min-width: 56.01rem)').addEventListener('change', (e) => e.matches && !menu.hidden && setMenu(false));

/* ── Scroll-linked values ─────────────────────────────────── */
// [data-scrub]        → --p runs 0→1 while the element crosses the viewport
// [data-scrub="pin"]  → --p runs 0→1 across the element's own scroll length (sticky sections)
const scrubs = $$('[data-scrub]');
const progress = $('[data-progress]');
let ticking = false;
function onScroll() {
  ticking = false;
  const y = scrollY, vh = innerHeight;
  nav?.classList.toggle('is-scrolled', y > 24);
  progress?.style.setProperty('--sp', clamp(y / Math.max(1, root.scrollHeight - vh)).toFixed(4));
  if (reduce) return;
  for (const el of scrubs) {
    const r = el.getBoundingClientRect();
    if (r.bottom < -vh * 0.5 || r.top > vh * 1.5) continue;
    const p = el.dataset.scrub === 'pin' ? clamp(-r.top / Math.max(1, r.height - vh)) : clamp((vh - r.top) / (vh + r.height));
    el.style.setProperty('--p', p.toFixed(4));
  }
}
addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });
addEventListener('resize', onScroll, { passive: true });
onScroll();

/* ── In-view: headline reveals and "run only while visible" animations ── */
const io = new IntersectionObserver((entries) => {
  for (const e of entries) {
    if (e.target.hasAttribute('data-watch')) e.target.classList.toggle('in', e.isIntersecting);
    else if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }
}, { rootMargin: '0px 0px -8% 0px', threshold: 0.12 });
// The clip is applied to an inner wrapper so the observed element itself always has a visible box.
$$('[data-lines]').forEach((el) => { el.innerHTML = `<span class="l">${el.innerHTML}</span>`; });
$$('[data-lines], [data-watch]').forEach((el) => io.observe(el));

/* ── Count-up numbers ─────────────────────────────────────── */
const counts = $$('[data-count]');
if (counts.length && !reduce) {
  const cio = new IntersectionObserver((entries) => {
    for (const e of entries) {
      if (!e.isIntersecting) continue;
      cio.unobserve(e.target);
      const end = +e.target.dataset.count, t0 = performance.now(), dur = 1600;
      const step = (t) => {
        const k = clamp((t - t0) / dur);
        e.target.textContent = Math.round(end * (1 - Math.pow(1 - k, 4)));
        if (k < 1) requestAnimationFrame(step);
      };
      e.target.textContent = '0';
      requestAnimationFrame(step);
    }
  }, { threshold: 0.6 });
  counts.forEach((c) => cio.observe(c));
}

/* ── Pointer interactions (mouse / trackpad only) ─────────── */
if (fine && !reduce) {
  // Magnetic buttons: the button leans a few pixels toward the cursor.
  $$('[data-magnetic]').forEach((el) => {
    el.addEventListener('pointermove', (e) => {
      const r = el.getBoundingClientRect();
      el.style.transform = `translate(${((e.clientX - r.left) / r.width - 0.5) * 10}px, ${((e.clientY - r.top) / r.height - 0.5) * 8}px)`;
    });
    el.addEventListener('pointerleave', () => { el.style.transform = ''; });
  });
  // Tilt: cards rotate a few degrees and expose --mx/--my for a cursor-following highlight.
  $$('[data-tilt]').forEach((el) => {
    const max = +el.dataset.tilt || 4;
    el.addEventListener('pointermove', (e) => {
      const r = el.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      el.style.setProperty('--mx', x.toFixed(3));
      el.style.setProperty('--my', y.toFixed(3));
      el.style.transform = `perspective(900px) rotateX(${(0.5 - y) * max}deg) rotateY(${(x - 0.5) * max}deg)`;
    });
    el.addEventListener('pointerleave', () => { el.style.transform = ''; });
  });
  // Light that follows the cursor inside marked sections.
  $$('[data-glow]').forEach((el) => {
    el.addEventListener('pointermove', (e) => {
      const r = el.getBoundingClientRect();
      el.style.setProperty('--gx', ((e.clientX - r.left) / r.width).toFixed(3));
      el.style.setProperty('--gy', ((e.clientY - r.top) / r.height).toFixed(3));
    });
  });
  // Showcase stage leans with the cursor.
  $$('[data-stage]').forEach((el) => {
    el.addEventListener('pointermove', (e) => {
      const r = el.getBoundingClientRect();
      el.style.setProperty('--tx', ((e.clientX - r.left) / r.width - 0.5).toFixed(3));
      el.style.setProperty('--ty', ((e.clientY - r.top) / r.height - 0.5).toFixed(3));
    });
    el.addEventListener('pointerleave', () => { el.style.setProperty('--tx', 0); el.style.setProperty('--ty', 0); });
  });
}

/* ── Connected-business network: highlight a system's links ── */
$$('[data-net]').forEach((net) => {
  const lines = $$('.net__l, .net__x', net);
  const set = (i) => {
    net.classList.toggle('is-focus', i !== null);
    lines.forEach((l) => l.classList.toggle('is-hot', i !== null && (l.dataset.a === i || l.dataset.b === i)));
  };
  $$('.net__node', net).forEach((n) => {
    const i = n.dataset.i;
    n.addEventListener('pointerenter', () => set(i));
    n.addEventListener('pointerleave', () => set(null));
    n.addEventListener('focus', () => set(i));
    n.addEventListener('blur', () => set(null));
  });
  // Pause the SVG pulses while the diagram is off screen.
  const svg = $('svg', net);
  new IntersectionObserver(([e]) => (e.isIntersecting ? svg.unpauseAnimations() : svg.pauseAnimations())).observe(net);
});

/* ── Footer year ──────────────────────────────────────────── */
$$('[data-year]').forEach((el) => (el.textContent = new Date().getFullYear()));

/* ── Cookie consent + analytics ───────────────────────────── */
// Tracking IDs come from site.config.mjs / .env. Nothing loads until the visitor accepts.
const A = window.ADS?.analytics || {};
const KEY = 'ads-consent';
const banner = $('[data-consent]');
const read = () => { try { return localStorage.getItem(KEY); } catch { return null; } };
const write = (v) => { try { localStorage.setItem(KEY, v); } catch {} };
const addScript = (src) => { const s = document.createElement('script'); s.async = true; s.src = src; document.head.append(s); };
let loaded = false;
function loadTracking() {
  if (loaded) return; loaded = true;
  window.dataLayer = window.dataLayer || [];
  if (A.gtmId) { window.dataLayer.push({ 'gtm.start': Date.now(), event: 'gtm.js' }); addScript('https://www.googletagmanager.com/gtm.js?id=' + encodeURIComponent(A.gtmId)); }
  if (A.ga4Id) { window.gtag = function () { window.dataLayer.push(arguments); }; gtag('js', new Date()); gtag('config', A.ga4Id); addScript('https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(A.ga4Id)); }
  if (A.metaPixelId) {
    const f = (window.fbq = function () { f.callMethod ? f.callMethod.apply(f, arguments) : f.queue.push(arguments); });
    f.queue = []; f.loaded = true; f.version = '2.0'; window._fbq = f;
    addScript('https://connect.facebook.net/en_US/fbevents.js'); fbq('init', A.metaPixelId); fbq('track', 'PageView');
  }
  if (A.linkedinPartnerId) { window._linkedin_data_partner_ids = [A.linkedinPartnerId]; addScript('https://snap.licdn.com/li.lms-analytics/insight.min.js'); }
}
if (banner) {
  const state = read();
  if (state === 'granted') loadTracking(); else if (!state) banner.hidden = false;
  $$('[data-consent-set]').forEach((b) => b.addEventListener('click', () => {
    write(b.dataset.consentSet); banner.hidden = true;
    if (b.dataset.consentSet === 'granted') loadTracking(); else if (loaded) location.reload();
  }));
}
$$('[data-consent-open]').forEach((b) => {
  if (!banner) { b.closest('li')?.remove(); return; }
  b.addEventListener('click', () => { banner.hidden = false; $('button', banner).focus(); });
});

// Lets other scripts report conversions (e.g. the contact form) without knowing which tools are installed.
window.adsTrack = (name, data = {}) => {
  if (!loaded) return;
  window.dataLayer?.push({ event: name, ...data });
  if (window.gtag && A.ga4Id) gtag('event', name, data);
  if (window.fbq && name === 'generate_lead') fbq('track', 'Lead');
};

// Website screens: only start gliding once both screenshots are loaded and decoded, so the
// first movement is never a stutter while an image is still arriving.
$$('.case3__v').forEach((v) => {
  Promise.all([...v.querySelectorAll('img')].map((i) => (i.decode ? i.decode().catch(() => {}) : null))).then(() => requestAnimationFrame(() => v.classList.add('ready')));
});
