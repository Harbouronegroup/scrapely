// Option 2 hero background: a slow "spectrum silk" field drawn in one fragment shader.
// Rendered at half resolution (it is all soft gradients), paused off screen, one still frame
// under reduced motion, and the CSS gradient behind it stays visible if WebGL is missing.
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

const VERT = 'attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}';
const FRAG = `
precision mediump float;
uniform vec2 uRes, uMouse;
uniform float uTime, uSoft;
float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); vec2 u=f*f*(3.-2.*f);
  return mix(mix(hash(i),hash(i+vec2(1,0)),u.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),u.x),u.y); }
float fbm(vec2 p){ float v=0., a=.5; for(int i=0;i<5;i++){ v+=a*noise(p); p=p*2.03+vec2(1.7,9.2); a*=.5; } return v; }
void main(){
  vec2 uv=gl_FragCoord.xy/uRes;
  vec2 p=(uv-.5)*vec2(uRes.x/uRes.y,1.)*2.;
  float t=uTime*.06;
  vec2 q=vec2(fbm(p*1.1+vec2(0.,t)), fbm(p*1.1+vec2(5.2,-t)));
  vec2 r=vec2(fbm(p+2.2*q+vec2(1.7,9.2)+uMouse*.35+t*.6), fbm(p+2.2*q+vec2(8.3,2.8)-t*.4));
  float n=fbm(p+2.4*r);
  // colour: violet -> electric blue -> aqua across the field
  vec3 violet=vec3(.36,.5,1.), blue=vec3(.31,.48,1.), aqua=vec3(.26,.89,.81);
  vec3 col=mix(violet, blue, smoothstep(.2,.7,uv.x+r.x*.4));
  col=mix(col, aqua, smoothstep(.55,.95,n+uv.x*.25-.1));
  float glow=smoothstep(.35,.95,n)*1.15;
  // silk ribbons flowing through the field
  float rib=pow(abs(sin((p.y+n*1.8+r.y*.6)*3.2+uTime*.12)),28.)*.55;
  // keep the middle-top calm where the headline sits; light the lower edge
  float calm=smoothstep(.05,.95,length((uv-vec2(.5,.66))*vec2(1.05,1.5)));
  float floor_=smoothstep(.55,0.,uv.y)*.6;
  float k=(glow*.55+rib)*(mix(.18,1.,calm)+floor_)*mix(1.,.6,uSoft);
  vec3 base=vec3(.02,.02,.028);
  vec3 c=base+col*k;
  c+= (hash(gl_FragCoord.xy+uTime)-.5)*.018; // dither: no banding
  gl_FragColor=vec4(c,1.);
}`;

function start(canvas) {
  const gl = canvas.getContext('webgl', { antialias: false, alpha: false, powerPreference: 'low-power' });
  if (!gl) return;
  const sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); return gl.getShaderParameter(o, gl.COMPILE_STATUS) ? o : null; };
  const vs = sh(gl.VERTEX_SHADER, VERT), fs = sh(gl.FRAGMENT_SHADER, FRAG);
  if (!vs || !fs) return;
  const prog = gl.createProgram();
  gl.attachShader(prog, vs); gl.attachShader(prog, fs); gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return;
  gl.useProgram(prog);
  gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(prog, 'a');
  gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const U = { res: gl.getUniformLocation(prog, 'uRes'), mouse: gl.getUniformLocation(prog, 'uMouse'), time: gl.getUniformLocation(prog, 'uTime'), soft: gl.getUniformLocation(prog, 'uSoft') };
  gl.uniform1f(U.soft, canvas.dataset.aurora === 'soft' ? 1 : 0);

  const scale = innerWidth < 768 ? 0.35 : 0.5; // fewer pixels on phones keeps it smooth and battery-friendly
  const resize = () => {
    const w = Math.max(2, Math.round(canvas.clientWidth * scale)), h = Math.max(2, Math.round(canvas.clientHeight * scale));
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; gl.viewport(0, 0, w, h); }
    gl.uniform2f(U.res, w, h);
  };
  new ResizeObserver(() => { resize(); if (reduce) draw(performance.now()); }).observe(canvas);
  resize();

  const m = { x: 0, y: 0, tx: 0, ty: 0 };
  addEventListener('pointermove', (e) => { m.tx = e.clientX / innerWidth - 0.5; m.ty = 0.5 - e.clientY / innerHeight; }, { passive: true });
  let visible = true, raf = 0, frames = 0;
  const t0 = performance.now() - 20000 * Math.random();
  function draw(now) {
    m.x += (m.tx - m.x) * 0.03; m.y += (m.ty - m.y) * 0.03;
    gl.uniform1f(U.time, reduce ? 30 : (now - t0) / 1000);
    gl.uniform2f(U.mouse, m.x, m.y);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    if (++frames === 2) canvas.classList.add('is-on');
  }
  function loop(now) { raf = 0; if (!visible || document.hidden) return; draw(now); raf = requestAnimationFrame(loop); }
  const kick = () => { if (!raf && !reduce) raf = requestAnimationFrame(loop); };
  new IntersectionObserver(([e]) => { visible = e.isIntersecting; if (visible) kick(); }).observe(canvas);
  document.addEventListener('visibilitychange', kick);
  if (reduce) { draw(0); draw(0); } else kick();
}

if (!navigator.connection?.saveData) {
  const go = () => document.querySelectorAll('[data-aurora]').forEach(start);
  (window.requestIdleCallback || ((f) => setTimeout(f, 150)))(go);
}
