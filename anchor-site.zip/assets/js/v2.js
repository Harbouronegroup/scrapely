// Option 2 interactions: live-work viewer, growth-engine steps, value calculator,
// free-audit form, floating audit pill and the mobile action bar.
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));

/* Live work viewer: tabs that auto-advance, pause on hover/focus, and work by keyboard. */
$$('[data-viewer]').forEach((v) => {
  const tabs = $$('[role="tab"]', v), panes = $$('[role="tabpanel"]', v);
  const CYCLE = 5000; v.style.setProperty('--cycle', CYCLE + 'ms');
  let i = 0, timer = 0, paused = reduce;
  const show = (n, focus) => {
    i = (n + tabs.length) % tabs.length;
    tabs.forEach((t, k) => { t.setAttribute('aria-selected', String(k === i)); t.tabIndex = k === i ? 0 : -1; });
    panes.forEach((p, k) => (p.hidden = k !== i));
    if (focus) tabs[i].focus();
    // restart the progress bar
    const bar = $('i', tabs[i]); if (bar) { bar.style.animation = 'none'; void bar.offsetWidth; bar.style.animation = ''; }
    schedule();
  };
  const schedule = () => { clearTimeout(timer); if (!paused) timer = setTimeout(() => show(i + 1), CYCLE); };
  tabs.forEach((t, k) => {
    t.addEventListener('click', () => show(k));
    t.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight') { e.preventDefault(); show(i + 1, true); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); show(i - 1, true); }
    });
  });
  const pause = (p) => { paused = p || reduce; v.classList.toggle('is-paused', paused); schedule(); };
  v.addEventListener('pointerenter', () => pause(true));
  v.addEventListener('pointerleave', () => pause(false));
  v.addEventListener('focusin', () => pause(true));
  v.addEventListener('focusout', () => pause(false));
  new IntersectionObserver(([e]) => pause(!e.isIntersecting)).observe(v);
  if (reduce) v.classList.add('is-paused');
  // The stage flattens as it scrolls into view.
  const stage = $('.viewer__stage', v);
  const onScroll = () => { const r = v.getBoundingClientRect(); stage.style.setProperty('--vp', clamp(1 - (r.top - innerHeight * 0.25) / (innerHeight * 0.6)).toFixed(3)); };
  if (!reduce) { addEventListener('scroll', onScroll, { passive: true }); onScroll(); } else stage.style.setProperty('--vp', 1);
});

/* Growth engine: the pinned section's progress picks the active step. */
$$('[data-engine]').forEach((el) => {
  const steps = $$('.engine__steps > li', el), n = steps.length;
  let on = -1;
  const set = (k) => { if (k === on) return; on = k; el.dataset.on = k; steps.forEach((s, j) => s.classList.toggle('is-on', j === k)); };
  const update = () => {
    const r = el.getBoundingClientRect();
    const p = clamp(-r.top / Math.max(1, r.height - innerHeight));
    set(Math.min(n - 1, Math.floor(p * n * 0.999)));
  };
  set(0);
  addEventListener('scroll', () => requestAnimationFrame(update), { passive: true });
  update();
  // Clicking a step jumps to it.
  steps.forEach((s, k) => { s.style.cursor = 'pointer'; s.addEventListener('click', () => { const top = el.offsetTop + (k + 0.5) / n * (el.offsetHeight - innerHeight); scrollTo({ top, behavior: reduce ? 'auto' : 'smooth' }); }); });
});

/* Value calculator */
$$('[data-worth]').forEach((el) => {
  const gbp = new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP', maximumFractionDigits: 0 });
  const num = new Intl.NumberFormat('en-GB');
  const v = (k) => +$(`[data-i="${k}"]`, el).value;
  const o = (k, t) => { const x = $(`[data-o="${k}"]`, el); if (x) x.textContent = t; };
  const update = () => {
    const visits = v('visits'), now = v('now'), nw = Math.max(v('new'), now), value = v('value'), close = v('close');
    const extra = visits * (nw - now) / 100;
    const customers = extra * 12 * close / 100;
    o('visits', num.format(visits)); o('now', now.toFixed(1) + '%'); o('new', v('new').toFixed(1) + '%'); o('value', gbp.format(value)); o('close', close + '%');
    o('leads', num.format(Math.round(extra))); o('customers', num.format(Math.round(customers))); o('revenue', gbp.format(Math.round(customers) * value));
  };
  $$('input', el).forEach((i) => i.addEventListener('input', update));
  update();
});

/* Free audit form: posts to the same handler as the contact form (form_type=audit). */
$$('[data-audit]').forEach((form) => {
  const ts = $('[data-ts]', form); if (ts) ts.value = Date.now();
  const msg = $('[data-audit-msg]', form);
  const site = form.elements.website, email = form.elements.email;
  const say = (t, cls) => { msg.textContent = t; msg.className = 'audit__msg ' + (cls || ''); };
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const okSite = /\.[a-z]{2,}/i.test(site.value.trim()), okEmail = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim());
    site.setAttribute('aria-invalid', String(!okSite)); email.setAttribute('aria-invalid', String(!okEmail));
    if (!okSite) { say('Enter your website address, for example yourbusiness.co.uk.', 'is-err'); site.focus(); return; }
    if (!okEmail) { say('Enter an email address so we can send your audit.', 'is-err'); email.focus(); return; }
    const btn = $('button', form); btn.disabled = true; say('Sending…');
    try {
      if (window.ADS?.preview) await new Promise((r) => setTimeout(r, 700));
      else {
        const res = await fetch(form.action, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data.ok === false) throw new Error(data.error || 'send-failed');
      }
      form.classList.add('is-done');
      say(`Thanks. We’ll review ${site.value.trim()} and email your free audit to ${email.value.trim()} within two working days.`, 'is-ok');
      window.adsTrack?.('generate_lead', { form: 'audit' });
    } catch (err) {
      say(err.message === 'rate' ? 'You’ve sent several requests in a short time. Wait a few minutes and try again.' : 'Your request wasn’t sent because the server didn’t respond. Try again, or use the contact page.', 'is-err');
    } finally { btn.disabled = false; }
  });
});

/* Floating audit pill (desktop) and action bar (mobile) appear after the first screen. */
const float = $('[data-float]'), mbar = $('[data-mbar]');
const closing = $('#audit');
const toggleFloat = () => {
  const past = scrollY > innerHeight * 0.9;
  const nearEnd = closing ? closing.getBoundingClientRect().top < innerHeight : false;
  float?.classList.toggle('is-on', past && !nearEnd);
  mbar?.classList.toggle('is-on', past && !nearEnd);
};
addEventListener('scroll', toggleFloat, { passive: true });
toggleFloat();

/* Safety net for headline reveals: anything already on screen is shown even if an observer event was missed. */
const pending = () => [...document.querySelectorAll('[data-lines]:not(.in)')];
let revealQueued = false;
const revealVisible = () => {
  revealQueued = false;
  for (const el of pending()) { const r = el.getBoundingClientRect(); if (r.top < innerHeight * 0.95 && r.bottom > 0) el.classList.add('in'); }
};
addEventListener('scroll', () => { if (!revealQueued) { revealQueued = true; requestAnimationFrame(revealVisible); } }, { passive: true });
addEventListener('load', revealVisible);
setTimeout(revealVisible, 600);
