// Hero: an abstract "digital anchor" (ring, shank and holding arc in polished dark chrome,
// with a thin orbit) ray-marched in a single fragment shader. About 6 KB, no 3D library.
// It pauses off screen, lowers its own resolution if frames run slow, renders one still frame
// under reduced motion, and leaves the SVG still in place if WebGL is unavailable.
const canvas = document.querySelector('[data-hero]');
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const saveData = navigator.connection?.saveData;

const VERT = `attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}`;
const FRAG = `
precision highp float;
uniform vec2 uRes, uMouse, uCenter;
uniform float uTime, uScroll, uScale, uDust, uHalo;

mat2 rot(float a){ float c=cos(a), s=sin(a); return mat2(c,-s,s,c); }
float smin(float a, float b, float k){ float h=clamp(.5+.5*(b-a)/k,0.,1.); return mix(b,a,h)-k*h*(1.-h); }
float torus(vec3 p, float R, float r){ return length(vec2(length(p.xy)-R,p.z))-r; }
float capsule(vec3 p, float y0, float y1, float r){ p.y-=clamp(p.y,y0,y1); return length(p)-r; }
float arc(vec3 p, vec2 sc, float ra, float rb){ p.x=abs(p.x); float k=(sc.y*p.x>sc.x*p.y)?dot(p.xy,sc):length(p.xy); return sqrt(dot(p,p)+ra*ra-2.*ra*k)-rb; }

float box(vec3 p, vec3 b, float r){ vec3 q=abs(p)-b; return length(max(q,0.))+min(max(q.x,max(q.y,q.z)),0.)-r; }

// Three separate pieces turning at different rates. They only line up into the
// anchor glyph for a moment each rotation; the rest of the time it is a kinetic sculpture.
vec2 map(vec3 p){
  p.y -= sin(uTime*.7)*.04 + uScroll*.9;
  vec3 q=p; q.yz*=rot(-.14+uMouse.y*.22);
  float A=uTime*.3+uMouse.x*.55+uScroll*2.4;
  vec3 a1=q; a1.xz*=rot(A);
  vec3 a2=q; a2.xz*=rot(-A*.6+.9);
  float d=torus(a1-vec3(0.,1.02,0.),.3,.066);
  d=min(d,box(a1-vec3(0.,-.02,0.),vec3(.034,.56,.17),.03));
  vec3 a=a2-vec3(0.,-.06,0.); a.y=-a.y;
  d=min(d,arc(a,vec2(.932,.362),.96,.07));
  float dot_=length(q-vec3(0.,-.8,0.))-.085;
  vec3 h=p; h.yz*=rot(1.2); h.xz*=rot(.3); h.xy*=rot(uTime*.2);
  float o=1e3;
  if(uHalo>.5){ o=torus(h,1.6,.011);
  for(int i=0;i<3;i++){ float an=float(i)*2.094; o=min(o,length(h-1.6*vec3(cos(an),sin(an),0.))-.045); } }
  vec2 r=d<o ? vec2(d,0.) : vec2(o,1.);
  return dot_<r.x ? vec2(dot_,2.) : r;
}
vec3 normal(vec3 p){ vec2 e=vec2(.0015,-.0015); return normalize(e.xyy*map(p+e.xyy).x+e.yyx*map(p+e.yyx).x+e.yxy*map(p+e.yxy).x+e.xxx*map(p+e.xxx).x); }

// A small procedural studio: one soft key, a signal-blue strip that follows the cursor, a cyan kicker.
vec3 env(vec3 d){
  vec3 c=mix(vec3(.008,.01,.018),vec3(.04,.06,.13),d.y*.5+.5);
  c+=vec3(1.7)*smoothstep(.7,.96,dot(d,normalize(vec3(.5,.75,.45))));
  c+=vec3(.16,.36,1.)*2.6*smoothstep(.3,0.,abs(d.y+.05-uMouse.y*.3))*smoothstep(-.15,-.9,d.x-uMouse.x*.35);
  c+=vec3(.6,.92,1.)*1.3*smoothstep(.62,.98,dot(d,normalize(vec3(-.3,-.62,-.72))));
  c+=vec3(.9,.95,1.)*.55*smoothstep(.03,0.,abs(d.y-.34))*step(0.,d.z);
  return c;
}
float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
float dust(vec2 uv, float s, float sp){
  uv=uv*s+vec2(0.,-uTime*sp); vec2 g=floor(uv), f=fract(uv);
  float h=hash(g); vec2 o=vec2(hash(g+3.1),hash(g+7.7))*.7+.15;
  return step(.8,h)*smoothstep(.045,0.,length(f-o))*(.5+.5*sin(uTime*1.5+h*40.));
}
void main(){
  vec2 uv0=(gl_FragCoord.xy*2.-uRes)/uRes.y;
  vec2 uv=(uv0-uCenter)/uScale;
  vec3 col=vec3(0.); float alpha=0.;
  float pts=(dust(uv0+uMouse*.03,6.,.03)*.8+dust(uv0+uMouse*.07,11.,.05)*.45)*uDust;
  col+=vec3(.6,.75,1.)*pts; alpha+=pts;
  if(length(uv)<1.12){
    vec3 ro=vec3(0.,0.,5.2), rd=normalize(vec3(uv,-2.4));
    float t=3.2, md=1e3, id=0.; bool hit=false;
    for(int i=0;i<72;i++){
      vec2 m=map(ro+rd*t); md=min(md,m.x);
      if(m.x<.0016*t){ hit=true; id=m.y; break; }
      t+=m.x*.92; if(t>7.4) break;
    }
    if(hit){
      vec3 p=ro+rd*t, n=normal(p);
      float f=pow(1.-max(dot(n,-rd),0.),5.);
      vec3 e=env(reflect(rd,n));
      vec3 c=e*mix(vec3(.66,.72,.86),vec3(1.),f)+f*vec3(.12,.28,.9)*.8+vec3(.012,.016,.034);
      if(id>1.5) c=vec3(.16,.34,1.)*(1.6+2.*f)+e*.5;
      else if(id>.5) c=vec3(.5,.68,1.)*1.3+e*.4;
      c=c/(1.+c); c=pow(c,vec3(.4545));
      col=c; alpha=1.;
    } else {
      float g=exp(-md*7.)*.5;
      col+=vec3(.2,.38,1.)*g; alpha=max(alpha,g*.8);
    }
  }
  gl_FragColor=vec4(col,clamp(alpha,0.,1.));
}`;

function start() {
  const gl = canvas.getContext('webgl', { alpha: true, antialias: false, premultipliedAlpha: true, powerPreference: 'high-performance' });
  if (!gl) return;
  const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
  const prog = gl.createProgram();
  try { gl.attachShader(prog, sh(gl.VERTEX_SHADER, VERT)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FRAG)); } catch (e) { console.warn('Hero shader unavailable:', e.message); return; }
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return;
  gl.useProgram(prog);
  gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(prog, 'a');
  gl.enableVertexAttribArray(loc);
  gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const U = Object.fromEntries(['uRes', 'uMouse', 'uCenter', 'uTime', 'uScroll', 'uScale', 'uDust', 'uHalo'].map((n) => [n, gl.getUniformLocation(prog, n)]));

  const orbMode = canvas.dataset.mode === 'orb';
  gl.uniform1f(U.uDust, orbMode ? 0 : 1);
  gl.uniform1f(U.uHalo, orbMode ? 0 : 1);
  const small = () => innerWidth < 768;
  let quality = small() ? 0.6 : (devicePixelRatio > 1 ? 0.8 : 1); // fraction of device pixels; adapts below
  function resize() {
    // In the orbit the canvas is small, so render it supersampled (at least 2x) for a crisp, smooth-edged anchor.
    const dpr = orbMode ? Math.min(3, Math.max(2, (devicePixelRatio || 1) * 1.5)) : Math.min(devicePixelRatio || 1, 1.75) * quality;
    const w = Math.max(2, Math.round(canvas.clientWidth * dpr)), h = Math.max(2, Math.round(canvas.clientHeight * dpr));
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; gl.viewport(0, 0, w, h); }
    const aspect = w / h;
    gl.uniform2f(U.uRes, w, h);
    // Inside the hero orbit (data-mode="orb"): anchor centred, no dust, no extra ring.
    if (orbMode) { gl.uniform2f(U.uCenter, 0, -0.17); gl.uniform1f(U.uScale, 1.3); }
    else if (aspect > 1.15) { gl.uniform2f(U.uCenter, aspect * 0.5, 0.06); gl.uniform1f(U.uScale, 0.98); }
    else if (aspect > 0.8) { gl.uniform2f(U.uCenter, aspect * 0.35, 0.3); gl.uniform1f(U.uScale, 0.72); }
    else { gl.uniform2f(U.uCenter, 0, 0.36); gl.uniform1f(U.uScale, 0.6); }
  }
  new ResizeObserver(resize).observe(canvas);
  resize();

  const mouse = { x: 0, y: 0, tx: 0, ty: 0 };
  addEventListener('pointermove', (e) => { mouse.tx = (e.clientX / innerWidth) * 2 - 1; mouse.ty = -((e.clientY / innerHeight) * 2 - 1); }, { passive: true });

  let visible = true, raf = 0, last = 0, slow = 0, frames = 0;
  const t0 = performance.now();
  function frame(now) {
    raf = 0;
    if (!visible || document.hidden) return;
    mouse.x += (mouse.tx - mouse.x) * 0.05; mouse.y += (mouse.ty - mouse.y) * 0.05;
    gl.uniform1f(U.uTime, reduce ? 4.2 : (now - t0) / 1000);
    gl.uniform2f(U.uMouse, mouse.x, mouse.y);
    gl.uniform1f(U.uScroll, orbMode ? 0 : Math.min(1, scrollY / innerHeight));
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    if (frames++ === 1) canvas.classList.add('is-on');
    // Adaptive resolution: if several frames run long, render fewer pixels.
    if (last && now - last > 30) slow++; else slow = Math.max(0, slow - 1);
    if (!orbMode && slow > 24 && quality > 0.35) { quality -= 0.15; slow = 0; resize(); }
    last = now;
    if (!reduce) raf = requestAnimationFrame(frame);
  }
  const kick = () => { if (!raf) { last = 0; raf = requestAnimationFrame(frame); } };
  new IntersectionObserver(([e]) => { visible = e.isIntersecting; if (visible) kick(); }).observe(canvas);
  document.addEventListener('visibilitychange', kick);
  if (reduce) { addEventListener('resize', kick); requestAnimationFrame(frame); requestAnimationFrame(() => requestAnimationFrame(frame)); }
  canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); canvas.classList.remove('is-on'); });
  kick();
}

if (canvas && !saveData) {
  // Wait until the page has painted so the shader never competes with first render.
  (window.requestIdleCallback ? (f) => requestIdleCallback(f, { timeout: 700 }) : (f) => setTimeout(f, 200))(start);
}
