// Option 3: the "inspect this page" panel (tabs + real performance numbers from this visit).
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

$$('[data-inspect]').forEach((box) => {
  const tabs = $$('[role="tab"]', box), panels = $$('[role="tabpanel"]', box);
  const show = (i, focus) => {
    tabs.forEach((t, k) => { t.setAttribute('aria-selected', String(k === i)); t.tabIndex = k === i ? 0 : -1; });
    panels.forEach((p, k) => (p.hidden = k !== i));
    if (focus) tabs[i].focus();
    if (i === 2) measure();
  };
  tabs.forEach((t, i) => {
    t.addEventListener('click', () => show(i));
    t.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight') { e.preventDefault(); show((i + 1) % tabs.length, true); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); show((i - 1 + tabs.length) % tabs.length, true); }
    });
  });
});

// Real numbers from the browser's own Performance API: nothing here is made up.
function measure() {
  const el = $('[data-perf]'); if (!el) return;
  const set = (k, v) => { const d = $(`[data-m="${k}"]`, el); if (d) d.textContent = v; };
  const nav = performance.getEntriesByType('navigation')[0];
  const res = performance.getEntriesByType('resource');
  if (nav) {
    const ready = nav.domContentLoadedEventEnd || nav.responseEnd;
    set('ready', ready ? `${(ready / 1000).toFixed(2)} s` : 'n/a');
  } else set('ready', 'n/a');
  const bytes = [nav, ...res].reduce((t, e) => t + (e && (e.transferSize || e.encodedBodySize) || 0), 0);
  set('weight', bytes ? (bytes > 1048576 ? `${(bytes / 1048576).toFixed(2)} MB` : `${Math.round(bytes / 1024)} KB`) : 'cached');
  set('requests', String(res.length + 1));
}

// Hero: chips and light points travel round the tilted rings; nearer ones look larger.
const orb = document.querySelector('[data-orb]');
if (orb) {
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const RINGS = [[250, 70, -16], [190, 118, 24], [282, 44, 6]]; // rx, ry, tilt (same as the SVG)
  const items = [...orb.querySelectorAll('[data-ring]')].map((el) => ({ el, ring: RINGS[+el.dataset.ring], a: +el.dataset.start, v: +el.dataset.speed }));
  const tilt = orb.querySelector('.orb__tilt');
  const chips = (orb.__chips = new Float32Array(20));
  let ci = 0;
  for (const it of items) it.chip = it.el.classList.contains('orb__chip') ? ci++ : -1;
  let last = performance.now(), visible = true, raf = 0;
  const place = () => {
    const k = orb.clientWidth / 600; // SVG units to pixels
    for (const it of items) {
      const [rx, ry, r] = it.ring, t = (r * Math.PI) / 180;
      const x = Math.cos(it.a) * rx, y = Math.sin(it.a) * ry;
      const X = (x * Math.cos(t) - y * Math.sin(t)) * k, Y = (x * Math.sin(t) + y * Math.cos(t)) * k;
      const depth = (Math.sin(it.a) + 1) / 2; // 0 = behind the core, 1 = in front
      it.el.style.transform = `translate(-50%, -50%) translate(${X.toFixed(1)}px, ${Y.toFixed(1)}px) scale(${(0.78 + depth * 0.32).toFixed(3)})`;
      it.el.style.opacity = (0.45 + depth * 0.55).toFixed(2);
      it.el.style.zIndex = depth > 0.5 ? 4 : 0; // in front of the anchor, or behind it
      if (it.chip >= 0) { // tell the orbit shader where back chips are, so no ring draws through them
        const sc = 0.78 + depth * 0.32, o = it.chip * 4, back = depth <= 0.5;
        chips[o] = X / k; chips[o + 1] = Y / k;
        chips[o + 2] = back ? (it.el.offsetWidth * sc) / 2 / k : 0; chips[o + 3] = back ? (it.el.offsetHeight * sc) / 2 / k : 0;
      }
    }
  };
  const loop = (now) => {
    raf = 0;
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    for (const it of items) it.a += it.v * dt * 6;
    place();
    if (visible && !document.hidden) raf = requestAnimationFrame(loop);
  };
  const kick = () => { if (!raf && !reduce) { last = performance.now(); raf = requestAnimationFrame(loop); } };
  place();
  new IntersectionObserver(([e]) => { visible = e.isIntersecting; kick(); }).observe(orb);
  document.addEventListener('visibilitychange', kick);
  addEventListener('resize', place);
  if (matchMedia('(hover: hover) and (pointer: fine)').matches && !reduce) {
    addEventListener('pointermove', (e) => {
      tilt.style.setProperty('--px', (e.clientX / innerWidth - 0.5).toFixed(3));
      tilt.style.setProperty('--py', (e.clientY / innerHeight - 0.5).toFixed(3));
    }, { passive: true });
  }
  kick();
}
