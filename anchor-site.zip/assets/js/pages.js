// Interactive pieces used on the service and work pages. Each block does nothing if its element is absent.
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

/* Before / after slider (website refresh). A real range input, so it works by keyboard and touch. */
$$('[data-compare]').forEach((el) => {
  const input = $('input', el);
  const set = () => el.style.setProperty('--x', input.value + '%');
  input.addEventListener('input', set);
  set();
});

/* "Generate again" (AI design): re-rolls the abstract tiles. Purely illustrative. */
$$('[data-gen]').forEach((el) => {
  const tiles = $$('.gen__grid i', el);
  const rnd = (a, b) => Math.round(a + Math.random() * (b - a));
  const roll = () => {
    const base = rnd(180, 300);
    tiles.forEach((t) => {
      const s = t.style;
      s.setProperty('--h1', base + rnd(-40, 40)); s.setProperty('--h2', base + rnd(-90, 60)); s.setProperty('--h3', base + rnd(-20, 50));
      s.setProperty('--x1', rnd(10, 90) + '%'); s.setProperty('--y1', rnd(10, 90) + '%');
      s.setProperty('--x2', rnd(10, 90) + '%'); s.setProperty('--y2', rnd(10, 90) + '%');
      s.setProperty('--a', rnd(0, 360) + 'deg');
      if (!reduce) { t.style.animation = 'none'; void t.offsetWidth; t.style.animation = ''; }
    });
  };
  roll();
  $('[data-gen-go]', el).addEventListener('click', roll);
});

/* Admin-cost estimate (AI automation). Assumptions are stated beside the result. */
$$('[data-calc]').forEach((el) => {
  const WEEKS = 46, SHARE = 0.6;
  const v = (n) => +$(`[data-in="${n}"]`, el).value;
  const out = (n, t) => { $(`[data-out="${n}"]`, el).textContent = t; };
  const gbp = new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP', maximumFractionDigits: 0 });
  const update = () => {
    const hours = Math.round(v('people') * v('hours') * WEEKS * SHARE);
    out('people', v('people')); out('hours', v('hours')); out('rate', gbp.format(v('rate')));
    out('saved', hours.toLocaleString('en-GB')); out('value', gbp.format(hours * v('rate')));
  };
  $$('input', el).forEach((i) => i.addEventListener('input', update));
  update();
});

/* Work filters */
$$('[data-filters]').forEach((bar) => {
  const cases = $$('[data-cases] .case');
  const status = $('[data-filter-status]');
  const apply = (f) => {
    let n = 0;
    cases.forEach((c) => { const show = f === 'all' || c.dataset.tags.split(',').includes(f); c.classList.toggle('is-hidden', !show); if (show) n++; });
    $$('button', bar).forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.filter === f)));
    if (status) status.textContent = `${n} project${n === 1 ? '' : 's'} shown`;
  };
  bar.addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (document.startViewTransition && !reduce) document.startViewTransition(() => apply(b.dataset.filter)); else apply(b.dataset.filter);
  });
});
