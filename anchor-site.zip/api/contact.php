<?php
// Anchor Digital Solutions: enquiry and free-audit form handler. Replies with JSON.
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

$TO   = 'Info@Anchor-Digital.co.uk';
$FROM = 'noreply@anchor-digital.co.uk';

function out($ok, $error = null, $code = 200) {
  http_response_code($code);
  echo json_encode($error ? ['ok' => $ok, 'error' => $error] : ['ok' => $ok]);
  exit;
}
function field($k, $max = 2000) {
  $v = isset($_POST[$k]) ? trim((string)$_POST[$k]) : '';
  $v = str_replace(["\r", "\0"], '', $v);
  return mb_substr($v, 0, $max);
}
function oneline($v) { return preg_replace('/[\n\t]+/', ' ', $v); }

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') out(false, 'method', 405);

// Spam traps: hidden field must be empty, and the form must not be sent implausibly fast.
if (field('company_url') !== '') out(true);
$t = (int)field('t', 20);
if ($t > 0 && (microtime(true) * 1000 - $t) < 2500) out(true);

// Simple rate limit: 5 sends per IP per 10 minutes.
$ip = $_SERVER['REMOTE_ADDR'] ?? 'x';
$rf = sys_get_temp_dir() . '/ads_rl_' . md5($ip);
$hits = array_filter(@json_decode(@file_get_contents($rf), true) ?: [], fn($h) => $h > time() - 600);
if (count($hits) >= 5) out(false, 'rate', 429);
$hits[] = time(); @file_put_contents($rf, json_encode(array_values($hits)));

$type  = field('form_type', 20) === 'audit' ? 'audit' : 'enquiry';
$email = oneline(field('email', 200));
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) out(false, 'validation', 422);

if ($type === 'audit') {
  $site = oneline(field('website', 300));
  if ($site === '') out(false, 'validation', 422);
  $subject = 'Free website audit request: ' . $site;
  $body = "New free audit request\n\nWebsite: $site\nEmail: $email\n";
} else {
  $first = oneline(field('first_name', 100)); $last = oneline(field('last_name', 100));
  $service = oneline(field('service', 100)); $message = field('message', 5000);
  if ($first === '' || $last === '' || $service === '' || mb_strlen($message) < 10) out(false, 'validation', 422);
  $subject = 'New enquiry: ' . $service . ' from ' . $first . ' ' . $last;
  $body  = "New project enquiry\n\n";
  $body .= "Name: $first $last\n";
  $body .= "Company: " . oneline(field('company', 200)) . "\n";
  $body .= "Email: $email\n";
  $body .= "Phone: " . oneline(field('phone', 50)) . "\n";
  $body .= "Website: " . oneline(field('website', 300)) . "\n";
  $body .= "Service: $service\n";
  $body .= "Budget: " . oneline(field('budget', 100)) . "\n";
  $body .= "Discovery call: " . (field('discovery_call', 10) === 'Yes' ? 'Yes' : 'No') . "\n\n";
  $body .= "Message:\n$message\n";
}
$body .= "\nSent from anchor-digital.co.uk on " . date('j M Y, H:i') . "\n";

$headers = [
  'From: Anchor Digital Website <' . $FROM . '>',
  'Reply-To: ' . $email,
  'Content-Type: text/plain; charset=UTF-8',
];
$sent = mail($TO, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, implode("\r\n", $headers), '-f' . $FROM);
$sent ? out(true) : out(false, 'send-failed', 500);
